// Initialize Firebase
import firebase from 'firebase'
var config = {
  apiKey: 'AIzaSyDuaWw7MIzM1nTDR0iID5xvKy2Dh3dTJns',
  authDomain: 'appmedicion-ucc.firebaseapp.com',
  databaseURL: 'https://appmedicion-ucc.firebaseio.com',
  projectId: 'appmedicion-ucc',
  storageBucket: 'appmedicion-ucc.appspot.com',
  messagingSenderId: '510414957297'
}
firebase.initializeApp(config)

export const db = firebase.database()
