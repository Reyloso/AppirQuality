export default [
  // { 'header': 'Admin' },
  { 'href': '/', 'title': 'Inicio', 'icon': 'home' },
  { 'href': '/mediciones', 'title': 'Mediciones', 'icon': 'view_list' },
  { 'href': '/mapas', 'title': 'Mapas', 'icon': 'map' },
  // { divider: true },
  { divider: true },
  { 'header': 'System' },
  { 'href': '/usuarios', 'title': 'Usuarios', 'icon': 'people' },
  { 'href': '/settings', 'title': 'Settings', 'icon': 'settings' }
]
